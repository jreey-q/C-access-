﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.Load += new EventHandler(Form2_Load); // 注册Form1_Load事件
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                InitializeChart();
            }
            catch (Exception ex)
            {
                MessageBox.Show("图表初始化失败: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void InitializeChart()
        {
            // 创建Chart对象
            chart = new Chart();
            chart.Dock = DockStyle.Fill;
            this.Controls.Add(chart);

            // 添加ChartArea
            ChartArea chartArea = new ChartArea();
            chart.ChartAreas.Add(chartArea);

            // 添加Series
            Series series = new Series();
            series.ChartType = SeriesChartType.Pie;
            chart.Series.Add(series);

            // 从Access数据库获取数据
            DataTable dataTable = GetDataFromAccessDatabase();
            if (dataTable != null && dataTable.Rows.Count > 0)
            {
                BindDataToChart(dataTable, series);
            }
            else
            {
                MessageBox.Show("没有从数据库中检索到数据。", "数据检索错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private DataTable GetDataFromAccessDatabase()
        {
            DataTable dataTable = new DataTable();
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\123\Documents\student.accdb";
            string query = "SELECT 性别, COUNT(*) AS 数量 FROM student GROUP BY 性别";

            try
            {
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection);
                    adapter.Fill(dataTable);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("数据库连接失败: " + ex.Message, "数据库错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // 调试输出，查看数据是否加载
            foreach (DataRow row in dataTable.Rows)
            {
                MessageBox.Show($"性别: {row["性别"]}, 数量: {row["数量"]}");
            }

            return dataTable;
        }

        private void BindDataToChart(DataTable dataTable, Series series)
        {
            if (dataTable.Rows.Count == 0)
            {
                MessageBox.Show("没有从数据库中检索到数据。", "数据检索错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            foreach (DataRow row in dataTable.Rows)
            {
                series.Points.AddXY(row["性别"].ToString(), Convert.ToDouble(row["数量"]));
            }

            // 设置饼状图的属性，显示标签和百分比
            series["PieLabelStyle"] = "Outside";
            series["LabelFormat"] = "N0"; // 显示整数
            series["PieLabelStyle"] = "Exploded"; // 可以设置为爆炸视图以更清晰显示
        }


        private void chart1_Click(object sender, EventArgs e)
        {
            
    }
    }
}
