﻿namespace homwork
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            数据添加ToolStripMenuItem = new ToolStripMenuItem();
            添加ToolStripMenuItem = new ToolStripMenuItem();
            查询及改动ToolStripMenuItem = new ToolStripMenuItem();
            删除ToolStripMenuItem = new ToolStripMenuItem();
            查询ToolStripMenuItem2 = new ToolStripMenuItem();
            学生成绩ToolStripMenuItem = new ToolStripMenuItem();
            查询ToolStripMenuItem = new ToolStripMenuItem();
            数据分析ToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            男女比例ToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { 数据添加ToolStripMenuItem, 数据分析ToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(860, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // 数据添加ToolStripMenuItem
            // 
            数据添加ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { 添加ToolStripMenuItem, 删除ToolStripMenuItem, 学生成绩ToolStripMenuItem });
            数据添加ToolStripMenuItem.Name = "数据添加ToolStripMenuItem";
            数据添加ToolStripMenuItem.Size = new Size(83, 24);
            数据添加ToolStripMenuItem.Text = "数据管理";
            // 
            // 添加ToolStripMenuItem
            // 
            添加ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { 查询及改动ToolStripMenuItem });
            添加ToolStripMenuItem.Name = "添加ToolStripMenuItem";
            添加ToolStripMenuItem.Size = new Size(152, 26);
            添加ToolStripMenuItem.Text = "学生信息";
            // 
            // 查询及改动ToolStripMenuItem
            // 
            查询及改动ToolStripMenuItem.Name = "查询及改动ToolStripMenuItem";
            查询及改动ToolStripMenuItem.Size = new Size(122, 26);
            查询及改动ToolStripMenuItem.Text = "查询";
            查询及改动ToolStripMenuItem.Click += 查询及改动ToolStripMenuItem_Click;
            // 
            // 删除ToolStripMenuItem
            // 
            删除ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { 查询ToolStripMenuItem2 });
            删除ToolStripMenuItem.Name = "删除ToolStripMenuItem";
            删除ToolStripMenuItem.Size = new Size(152, 26);
            删除ToolStripMenuItem.Text = "课程信息";
            删除ToolStripMenuItem.Click += 删除ToolStripMenuItem_Click;
            // 
            // 查询ToolStripMenuItem2
            // 
            查询ToolStripMenuItem2.Name = "查询ToolStripMenuItem2";
            查询ToolStripMenuItem2.Size = new Size(122, 26);
            查询ToolStripMenuItem2.Text = "查询";
            查询ToolStripMenuItem2.Click += 查询ToolStripMenuItem2_Click;
            // 
            // 学生成绩ToolStripMenuItem
            // 
            学生成绩ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { 查询ToolStripMenuItem });
            学生成绩ToolStripMenuItem.Name = "学生成绩ToolStripMenuItem";
            学生成绩ToolStripMenuItem.Size = new Size(152, 26);
            学生成绩ToolStripMenuItem.Text = "学生成绩";
            // 
            // 查询ToolStripMenuItem
            // 
            查询ToolStripMenuItem.Name = "查询ToolStripMenuItem";
            查询ToolStripMenuItem.Size = new Size(122, 26);
            查询ToolStripMenuItem.Text = "查询";
            查询ToolStripMenuItem.Click += 查询ToolStripMenuItem_Click_1;
            // 
            // 数据分析ToolStripMenuItem
            // 
            数据分析ToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { 男女比例ToolStripMenuItem });
            数据分析ToolStripMenuItem.Name = "数据分析ToolStripMenuItem";
            数据分析ToolStripMenuItem.Size = new Size(83, 24);
            数据分析ToolStripMenuItem.Text = "数据分析";
            数据分析ToolStripMenuItem.Click += 数据分析ToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft YaHei UI", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point, 134);
            label1.Location = new Point(220, 164);
            label1.Name = "label1";
            label1.Size = new Size(0, 58);
            label1.TabIndex = 1;
            label1.Click += label1_Click;
            // 
            // 男女比例ToolStripMenuItem
            // 
            男女比例ToolStripMenuItem.Name = "男女比例ToolStripMenuItem";
            男女比例ToolStripMenuItem.Size = new Size(224, 26);
            男女比例ToolStripMenuItem.Text = "男女比例";
            男女比例ToolStripMenuItem.Click += 男女比例ToolStripMenuItem_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(860, 480);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form2";
            Text = "学生管理系统";
            Load += Form2_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem 数据添加ToolStripMenuItem;
        private ToolStripMenuItem 添加ToolStripMenuItem;
        private ToolStripMenuItem 删除ToolStripMenuItem;
        private ToolStripMenuItem 查询ToolStripMenuItem2;
        private ToolStripMenuItem 学生成绩ToolStripMenuItem;
        private ToolStripMenuItem 查询及改动ToolStripMenuItem;
        private ToolStripMenuItem 查询ToolStripMenuItem;
        private ToolStripMenuItem 数据分析ToolStripMenuItem;
        private Label label1;
        private ToolStripMenuItem 男女比例ToolStripMenuItem;
    }
}