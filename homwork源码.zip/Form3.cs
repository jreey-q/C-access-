﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace homwork
{
    public partial class Form3 : Form
    {
        
        DataSet myds = new DataSet();
        DataView mydv = new DataView();
        OleDbDataAdapter myda = new OleDbDataAdapter();
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {




            string condstr = "";
            if (int.TryParse(textBox1.Text, out int studentId) && studentId > 0)
            {
                condstr = "学号 = " + studentId;
            }
            else if (!string.IsNullOrWhiteSpace(textBox1.Text))
            {
                condstr = "姓名 Like '" + textBox1.Text + "%' OR 班号 Like '" + textBox1.Text + "%' OR 性别 Like '" + textBox1.Text + "%' OR 民族 Like '" + textBox1.Text + "%'";
            }

            if (!string.IsNullOrEmpty(condstr))
            {
                mydv.RowFilter = condstr;
            }
            else
            {
                mydv.RowFilter = ""; // 清除过滤条件
            }
            // 可以根据需要添加更多条件
            // ...





        }
        private void DisplayQueryResults(string connectionString, string query, string studentID, ListBox listBox)
        {





        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            string mystr;
            OleDbConnection myconn = new OleDbConnection();
            DataSet myds1 = new DataSet();

            mystr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Class1.mystr2;
            myconn.ConnectionString = mystr;
            myconn.Open();
            OleDbDataAdapter myda = new OleDbDataAdapter("SELECT * FROM student ", myconn);
            myda.Fill(myds1, "student");

            mydv = myds1.Tables["student"].DefaultView;
            ////获得DataView对象mydv
            //                                            //以下设置DataGridView1的属性
            dataGridView1.DataSource = mydv;
            dataGridView1.ScrollBars = ScrollBars.Vertical;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            OleDbCommandBuilder mycmdbuilder = new OleDbCommandBuilder(myda);

            myconn.Close();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form form4 = new Form4();
            form4.Show();
        }

       
    }

    // 提取字符串中的第一个单词（原方法名可能有误，因为根据描述它应该返回第一个字符串而不是“第一个字符串”这种表述）




}







    
    

