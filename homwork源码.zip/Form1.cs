using System.Data;
using System.Data.OleDb;

namespace homwork
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string mystr;
            OleDbConnection myconn = new OleDbConnection();
            mystr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + textBox1.Text;Class1.mystr2 = textBox1.Text;
            myconn.ConnectionString = mystr;
            myconn.Open();
            if (myconn.State == ConnectionState.Open)
                label2.Text = "�ɹ����ӵ�Access���ݿ�";
            else
                label2.Text = "�������ӵ�Access���ݿ�";
            
            Class1.mystr1 = label2.Text;
           
            Form form2 = new Form2();
            form2.Show();
            

            myconn.Close();


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
