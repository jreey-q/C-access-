﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homwork
{
    public class Class1
    {
        public static string mystr2;
        public static string mystr1;
        
    }
}
