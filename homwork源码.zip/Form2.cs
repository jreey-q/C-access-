﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homwork
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void 查询ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form form3 = new Form3();
            form3.Show();
        }

        private void 查询及改动ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form form3 = new Form3();
            form3.Show();

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text = Class1.mystr1;
        }

        private void 删除ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 查询ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Form form6 = new From6();
            form6.Show();
        }

        private void 查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 查询ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Form form8 = new Form8();
            form8.Show();
        }

        private void 数据分析ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void 男女比例ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }
    }
}
