﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homwork
{
    public partial class Form9 : Form
    {
        OleDbDataAdapter myda = new OleDbDataAdapter();
        DataSet myds = new DataSet();
        public Form9()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            string mystr, mysql;
            OleDbConnection myconn = new OleDbConnection();
            mystr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Class1.mystr2;
            myconn.ConnectionString = mystr;
            myconn.Open();
            mysql = "SELECT * FROM score";
            myda = new OleDbDataAdapter(mysql, myconn);
            myda.Fill(myds, "score");
            dgv1.DataSource = myds.Tables["score"];
            dgv1.ColumnHeadersDefaultCellStyle.Font =
                new Font("隶书", 11);  //设置标题字体

            dgv1.ScrollBars = ScrollBars.Vertical;
            dgv1.CellBorderStyle = DataGridViewCellBorderStyle.Single;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OleDbCommandBuilder mycmdbuilder = new OleDbCommandBuilder(myda);
            //获取对应的修改命令
            if (myds.HasChanges())    //如果有数据改动
            {
                try
                {
                    myda.Update(myds, "score");   //更新数据源
                }
                catch (Exception ex)
                {
                    MessageBox.Show("数据修改不正确，如学号重复等", "信息提示");
                }
            }
        }
    }
}
